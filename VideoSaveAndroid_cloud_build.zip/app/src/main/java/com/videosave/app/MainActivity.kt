package com.videosave.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF142039)
private val Accent = Color(0xFF7895FF)
private val Muted = Color(0xFFA8B5CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VideoSaveScreen() }
    }
}

@Composable
private fun VideoSaveScreen() {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Вставьте ссылку на своё видео YouTube.") }
    val valid = isYouTubeLink(url)

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF1C2D4D), Navy)))) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Surface(shape = RoundedCornerShape(18.dp), color = Accent) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White,
                        modifier = Modifier.padding(13.dp).size(34.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text("VideoSave", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Помощник для сохранения своих видео", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(28.dp))
                Card(Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Ссылка на YouTube", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it.trim() },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("https://youtu.be/…", color = Muted) },
                            singleLine = true, shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF40516E),
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                cursorColor = Accent
                            )
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            if (valid) openUrl(context, url)
                            else message = "Сначала вставьте корректную ссылку YouTube."
                        }, enabled = valid, modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.OpenInNew, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Открыть видео", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(9.dp))
                        OutlinedButton(onClick = { openUrl(context, "https://studio.youtube.com/") },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp)) {
                            Text("Открыть YouTube Studio")
                        }
                        Spacer(Modifier.height(13.dp))
                        Text(message, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Card(Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Качество видео", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "YouTube не предоставляет сторонним приложениям официальный способ " +
                            "получать список потоков и принудительно выбирать 360p, 720p, 1080p или 4K. " +
                            "Поэтому VideoSave не будет показывать фиктивные варианты качества.",
                            color = Muted, fontSize = 13.sp, lineHeight = 19.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Для своих роликов откройте YouTube Studio. Если нужна исходная копия, " +
                            "воспользуйтесь Google Takeout. Доступное разрешение и способ экспорта " +
                            "определяет официальный сервис.",
                            color = Color(0xFFD7E0F2), fontSize = 13.sp, lineHeight = 19.sp
                        )
                        Spacer(Modifier.height(13.dp))
                        OutlinedButton(onClick = { openUrl(context, "https://takeout.google.com/") },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(14.dp)) {
                            Text("Открыть Google Takeout")
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "Скачивайте только свои видео или материалы, на которые у вас есть разрешение.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        }
    }
}

private fun isYouTubeLink(value: String): Boolean {
    if (!value.startsWith("https://") && !value.startsWith("http://")) return false
    val host = runCatching { Uri.parse(value).host?.lowercase() }.getOrNull() ?: return false
    return host == "youtube.com" || host.endsWith(".youtube.com") ||
        host == "youtu.be" || host.endsWith(".youtu.be")
}

private fun openUrl(context: Context, value: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value))) }
}
