package com.videosave.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLConnection
import java.net.URLDecoder
import java.util.Locale

private val Bg = Color(0xFF101216)
private val Panel = Color(0xFF1B2028)
private val Accent = Color(0xFF70D6A5)
private val Muted = Color(0xFF9AA4B2)

data class MediaInfo(val url: String, val name: String, val mime: String, val size: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VideoSaveScreen(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoSaveScreen(context: Context) {
    var link by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<MediaInfo?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Вставь прямую ссылку на видеофайл.") }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, secondary = Accent, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.VideoLibrary, null, tint = Accent, modifier = Modifier.size(34.dp))
                    Column {
                        Text("VideoSave", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Загрузка видео по прямой ссылке", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Ссылка на видео", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = link, onValueChange = { link = it; info = null },
                            modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://example.com/video.mp4") },
                            leadingIcon = { Icon(Icons.Default.Link, null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                scope.launch {
                                    busy = true; info = null
                                    try {
                                        val result = withContext(Dispatchers.IO) { inspectMedia(link.trim()) }
                                        info = result
                                        message = "Видео найдено. Можно загрузить файл."
                                    } catch (e: Exception) {
                                        message = e.message ?: "Не удалось проверить ссылку."
                                    } finally { busy = false }
                                }
                            },
                            enabled = !busy && link.isNotBlank(),
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                            else Text("Проверить ссылку")
                        }
                    }
                }
                info?.let { media ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Информация о файле", fontWeight = FontWeight.SemiBold)
                            Text(media.name, color = Accent)
                            Text("Формат: ${media.mime}")
                            Text("Размер: ${if (media.size > 0) formatSize(media.size) else "не указан"}")
                            Text("Качество зависит от самого файла. Если ссылка ведёт на один файл, выбрать другое разрешение нельзя.", color = Muted, style = MaterialTheme.typography.bodySmall)
                            Button(
                                onClick = {
                                    try {
                                        val request = DownloadManager.Request(Uri.parse(media.url))
                                            .setTitle(media.name)
                                            .setDescription("Загрузка через VideoSave")
                                            .setMimeType(media.mime)
                                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                            .setAllowedOverMetered(true)
                                            .setAllowedOverRoaming(false)
                                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VideoSave/${safeFileName(media.name)}")
                                        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                        manager.enqueue(request)
                                        message = "Загрузка добавлена. Следи за прогрессом в уведомлениях Android."
                                    } catch (e: Exception) {
                                        message = "Не удалось начать загрузку: ${e.message}"
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(52.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Download, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Скачать видео")
                            }
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Статус", fontWeight = FontWeight.SemiBold)
                        Text(message, color = Muted)
                    }
                }
                Text(
                    "Поддерживаются прямые HTTP(S)-ссылки на видеофайлы, которые разрешено скачивать. Ссылки на страницы YouTube и других видеосервисов не являются прямыми ссылками на файл.",
                    color = Muted, style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun inspectMedia(raw: String): MediaInfo {
    require(raw.startsWith("https://", true) || raw.startsWith("http://", true)) {
        "Введи полную ссылку, начинающуюся с http:// или https://."
    }
    val uri = Uri.parse(raw)
    require(uri.host != null) { "В ссылке не найден адрес сайта." }
    require(!uri.host!!.contains("youtube.com") && !uri.host!!.contains("youtu.be")) {
        "Это ссылка на страницу YouTube, а не прямая ссылка на видеофайл. VideoSave пока принимает прямые ссылки на разрешённые к скачиванию файлы."
    }
    val connection = (URL(raw).openConnection() as HttpURLConnection).apply {
        requestMethod = "HEAD"
        connectTimeout = 12000
        readTimeout = 12000
        instanceFollowRedirects = true
        setRequestProperty("User-Agent", "VideoSave/1.1")
    }
    try {
        val code = connection.responseCode
        require(code in 200..299) { "Сервер не отдал файл (HTTP $code). Ссылка может требовать входа или не поддерживать проверку." }
        val mime = (connection.contentType ?: "application/octet-stream").substringBefore(";").lowercase(Locale.ROOT)
        val pathName = URLDecoder.decode(Uri.parse(connection.url.toString()).lastPathSegment ?: "video", "UTF-8")
        val name = if (pathName.contains('.')) pathName else "$pathName.${extensionFor(mime)}"
        val validMime = mime.startsWith("video/") || name.substringAfterLast('.', "").lowercase() in setOf("mp4","m4v","mov","webm","mkv","avi")
        require(validMime) { "По этой ссылке не обнаружен видеофайл (тип: $mime)." }
        return MediaInfo(connection.url.toString(), name, mime, connection.contentLengthLong)
    } finally { connection.disconnect() }
}

private fun extensionFor(mime: String) = when (mime) {
    "video/webm" -> "webm"
    "video/quicktime" -> "mov"
    "video/x-matroska" -> "mkv"
    else -> "mp4"
}
private fun safeFileName(name: String) = name.replace(Regex("[^A-Za-z0-9А-Яа-я._ -]"), "_").take(100)
private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "не указан"
    val mb = bytes / 1024.0 / 1024.0
    return if (mb >= 1024) String.format(Locale.US, "%.2f ГБ", mb / 1024) else String.format(Locale.US, "%.1f МБ", mb)
}
